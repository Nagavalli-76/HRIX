import type { MetadataRoute } from "next";

import { SITE_URL } from "@/lib/seo/site";

const BASE_URL = SITE_URL;

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/admin",
          "/admin/",
          "/creator/dashboard",
          "/creator/dashboard/",
          "/creator/onboarding",
          "/creator/onboarding/",
          "/brand/dashboard",
          "/brand/dashboard/",
          "/api/",
          "/auth/",
          "/login",
          "/register",
          "/forgot-password",
          "/update-password",
          "/auth-error",
        ],
      },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
  };
}
