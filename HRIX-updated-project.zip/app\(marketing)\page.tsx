import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  Building2,
  HeartPulse,
  Hotel,
  Layers,
  Megaphone,
  MonitorCog,
  Palette,
  School,
  ShoppingBag,
  Sparkles,
  Target,
  Users,
  Video,
  Workflow,
} from "lucide-react";
import { Hero } from "@/components/marketing/Hero";
import { HeroNetwork } from "@/components/marketing/HeroNetwork";
import { TrustMetrics } from "@/components/marketing/TrustMetrics";
import { HowItWorks } from "@/components/marketing/HowItWorks";
import { BenefitsSection } from "@/components/marketing/BenefitsSection";
import { CreatorProfilePreview } from "@/components/marketing/previews/CreatorProfilePreview";
import { BrandDiscoveryPreview } from "@/components/marketing/previews/BrandDiscoveryPreview";
import { PricingTiers } from "@/components/marketing/PricingTiers";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/Button";
import { JsonLd } from "@/components/seo/JsonLd";
import { getOrganizationSchema, getWebSiteSchema } from "@/lib/seo/schema";
import { serviceList } from "@/data/services";
import { SITE_URL } from "@/lib/seo/site";

const DESCRIPTION =
  "HRIX helps businesses build their brand, reach their audience and grow through digital marketing, websites, lead generation, creator collaborations and business automation.";

export const metadata: Metadata = {
  title: { absolute: "HRIX | Digital Growth & Technology Solutions" },
  description: DESCRIPTION,
  alternates: { canonical: "/" },
  openGraph: {
    title: "HRIX | Digital Growth & Technology Solutions",
    description: DESCRIPTION,
    url: SITE_URL,
    siteName: "HRIX",
      images: [`${SITE_URL}/brand/hrix-logo.png`],
  },
  twitter: {
    card: "summary_large_image",
    title: "HRIX | Digital Growth & Technology Solutions",
    description: DESCRIPTION,
  },
};

const SERVICE_ICONS: Record<string, typeof Sparkles> = {
  "branding-and-identity": Layers,
  "influencer-marketing": Users,
  "digital-marketing-advertising": Megaphone,
  "social-media-marketing": Sparkles,
  "lead-generation": Target,
  "business-systems-automation": Workflow,
  "website-design-development": MonitorCog,
  "creative-design": Palette,
  "video-production": Video,
  seo: BarChart3,
  "whatsapp-marketing": Megaphone,
  "analytics-reporting": BarChart3,
};

const FOCUS_AREAS = [
  { title: "Brand Development & Digital Presence", icon: Layers },
  { title: "Digital Marketing & Creative Solutions", icon: Palette },
  { title: "Lead Generation & Customer Acquisition", icon: Target },
  { title: "Website Development & Technology", icon: MonitorCog },
  { title: "Business Growth & Automation", icon: Workflow },
];

const INDUSTRIES = [
  { title: "Real Estate & Property Development", icon: Building2 },
  { title: "Education & Institutions", icon: School },
  { title: "Healthcare & Clinics", icon: HeartPulse },
  { title: "Hospitality & Restaurants", icon: Hotel },
  { title: "Retail & E-commerce", icon: ShoppingBag },
  { title: "Professional Services", icon: Users },
  { title: "Startups & Growing Businesses", icon: Sparkles },
];

const GROWTH_STEPS = [
  ["Understand", "Study your business, market, competitors and target audience."],
  ["Strategize", "Develop a customized branding and marketing strategy."],
  ["Create", "Produce professional designs, videos, websites and campaigns."],
  ["Promote", "Reach the right audience through digital platforms and advertising."],
  ["Generate", "Build systems that capture customer enquiries and potential leads."],
  ["Connect", "Organize communication, follow-ups and customer engagement."],
  ["Optimize", "Analyze results and continuously improve marketing performance."],
] as const;

const WHY_HRIX = [
  "Multiple digital services under one partnership.",
  "Customized strategies for different industries.",
  "Creative and technology-driven execution.",
  "Performance-focused marketing.",
  "Transparent communication and reporting.",
  "Scalable solutions as your business grows.",
];

const CREATOR_JOURNEY = ["Discover", "Match", "Collaborate", "Create", "Measure", "Pay", "Grow"];

export default function HomePage() {
  return (
    <>
      <JsonLd data={[getOrganizationSchema(), getWebSiteSchema()]} />
      <Hero />

      <section aria-labelledby="introduction-heading" className="border-t border-line/70">
        <div className="container-page grid gap-8 py-16 md:grid-cols-[1.25fr_0.75fr] md:py-20">
          <div>
            <h2 id="introduction-heading" className="text-headline">Digital growth built around your business</h2>
            <div className="mt-5 max-w-3xl space-y-4 text-muted leading-relaxed">
              <p>HRIX helps businesses establish their digital presence, connect with potential customers and generate business opportunities.</p>
              <p>We combine creative strategy, digital marketing, technology and performance-driven solutions to help businesses grow in a competitive marketplace.</p>
              <p>From building a brand identity to developing websites, managing digital campaigns and generating customer enquiries, HRIX brings multiple business growth solutions under one roof.</p>
            </div>
          </div>
          <GlassCard className="flex flex-col justify-center border-orange-400/30">
            <p className="text-sm font-semibold uppercase tracking-wider text-muted">Our Philosophy</p>
            <p className="mt-4 text-2xl font-semibold leading-snug text-ink">One business. One growth strategy.</p>
            <p className="mt-1 text-2xl font-semibold leading-snug text-orange-300">Multiple digital solutions.</p>
          </GlassCard>
        </div>
      </section>

      <section aria-labelledby="focus-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-20">
          <h2 id="focus-heading" className="text-headline">Primary Focus Areas</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {FOCUS_AREAS.map(({ title, icon: Icon }) => (
              <GlassCard key={title} className="h-full">
                <Icon className="h-6 w-6 text-orange-300" aria-hidden />
                <h3 className="mt-4 text-base font-semibold text-ink">{title}</h3>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section id="industries" aria-labelledby="industries-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-20">
          <h2 id="industries-heading" className="text-headline">Industries We Serve</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {INDUSTRIES.map(({ title, icon: Icon }) => (
              <GlassCard key={title} className="flex items-center gap-4">
                <Icon className="h-5 w-5 shrink-0 text-orange-300" aria-hidden />
                <h3 className="text-sm font-medium text-ink">{title}</h3>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section aria-labelledby="services-overview-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-24">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              <p className="mb-3 text-sm font-semibold uppercase tracking-wider text-orange-300">Our Services</p>
              <h2 id="services-overview-heading" className="text-display">Digital solutions for business growth</h2>
              <p className="mt-4 text-muted">Strategy, creative work, technology and marketing support for businesses at every stage.</p>
            </div>
            <Link href="/services" className="inline-flex shrink-0 items-center gap-1.5 text-sm font-medium text-orange-300 hover:underline">
              Browse all 12 services <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {serviceList.map((service) => {
              const Icon = SERVICE_ICONS[service.slug] || Sparkles;
              return (
                <GlassCard key={service.slug} interactive className="flex h-full flex-col">
                  <Icon className="h-5 w-5 text-orange-300" aria-hidden />
                  <h3 className="mt-4 text-lg font-semibold text-ink">
                    <Link href={`/services/${service.slug}`} className="hover:text-orange-300">{service.name}</Link>
                  </h3>
                  <p className="mt-2 flex-1 text-sm text-muted leading-relaxed">{service.summary}</p>
                  <Link href={`/services/${service.slug}`} className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-orange-300 hover:underline">
                    Learn more <ArrowRight className="h-4 w-4" aria-hidden />
                  </Link>
                </GlassCard>
              );
            })}
          </div>
        </div>
      </section>

      <section id="process" aria-labelledby="growth-process-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-20">
          <p className="mb-3 text-sm font-semibold uppercase tracking-wider text-orange-300">Our Approach</p>
          <h2 id="growth-process-heading" className="text-headline">Growth Process</h2>
          <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {GROWTH_STEPS.map(([title, description], index) => (
              <li key={title}>
                <GlassCard className="h-full">
                  <span className="font-display text-3xl font-bold text-orange-300">{index + 1}</span>
                  <h3 className="mt-3 font-semibold text-ink">{title}</h3>
                  <p className="mt-2 text-sm text-muted leading-relaxed">{description}</p>
                </GlassCard>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section aria-labelledby="why-hrix-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-20">
          <h2 id="why-hrix-heading" className="text-headline">Why HRIX?</h2>
          <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {WHY_HRIX.map((item) => (
              <li key={item} className="flex gap-3 rounded-lg border border-line bg-surface/60 p-5 text-sm text-ink">
                <span aria-hidden className="text-orange-300">✓</span>{item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section aria-labelledby="creator-network-heading" className="border-t border-line/70">
        <div className="container-page py-16 md:py-20">
          <h2 id="creator-network-heading" className="text-headline">How the Creator Network works</h2>
          <p className="mt-3 max-w-xl text-muted">A structured journey for creators and brands to find each other and work together.</p>
          <div className="mt-8 grid items-center gap-8 lg:grid-cols-[1fr_1fr]">
            <HeroNetwork />
            <ol className="grid grid-cols-2 gap-3 text-sm text-muted sm:grid-cols-3">
              {CREATOR_JOURNEY.map((step, index) => (
                <li key={step} className="rounded-lg border border-line bg-surface/60 p-4">
                  <span className="mr-2 font-semibold text-orange-300">{index + 1}</span>{step}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>
      <HowItWorks />
      <TrustMetrics />

      <BenefitsSection
        id="for-creators"
        heading="Turn your influence into opportunities"
        body="A professional profile, campaign discovery and a clear record of every collaboration you complete."
        items={[
          { title: "Professional creator profile", description: "Show your platforms, audience and past work in one place." },
          { title: "Campaign discovery", description: "See campaigns matched to your category and audience." },
          { title: "Applications and portfolio", description: "Apply with your rate card and a portfolio brands can review." },
          { title: "Earnings tracking", description: "Follow payments and campaign history as they happen." },
        ]}
        ctaLabel="Join as Creator"
        ctaHref="/register?role=creator"
        preview={<CreatorProfilePreview />}
      />

      <BenefitsSection
        id="for-brands"
        heading="Find creators who fit your campaign"
        body="Filter by category, location and engagement, then manage the whole collaboration from one dashboard."
        items={[
          { title: "Creator discovery", description: "Filter by audience relevance, location, category and platform." },
          { title: "Shortlisting", description: "Compare creators side by side before you commit budget." },
          { title: "Campaign management", description: "Track applications, deliverables and results in one place." },
        ]}
        ctaLabel="For Brands"
        ctaHref="/brands"
        preview={<BrandDiscoveryPreview />}
        previewSide="left"
      />

      <section id="pricing" className="border-t border-line/70">
        <div className="container-page py-16 md:py-24">
          <div className="mx-auto max-w-xl text-center">
            <h2 className="text-headline">Creator membership</h2>
            <p className="mt-4 text-muted">Start with access, improve your profile, or take the complete creator growth path. No guaranteed campaigns or income — just structured support for your creator presence.</p>
          </div>
          <div className="mt-12"><PricingTiers /></div>
        </div>
      </section>

      <section aria-labelledby="closing-heading" className="border-t border-line/70">
        <div className="container-page py-16 text-center md:py-20">
          <h2 id="closing-heading" className="text-display">Let&apos;s Build Something That Grows.</h2>
          <p className="mt-4 text-sm font-medium text-orange-300">HRIX — Digital Growth &amp; Technology Solutions</p>
          <p className="mt-2 text-muted">Your Business. Our Strategy. Shared Growth.</p>
          <div className="mt-7"><Button href="/contact" size="lg">Let&apos;s Grow Together with HRIX</Button></div>
        </div>
      </section>
    </>
  );
}
