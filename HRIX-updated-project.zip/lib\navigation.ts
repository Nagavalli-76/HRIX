export interface NavItem {
  label: string;
  href: string;
}

/** Public website navigation. Shared by the navbar, mobile menu and footer. */
export const primaryNav: NavItem[] = [
  { label: "Services", href: "/services" },
  { label: "Industries", href: "/#industries" },
  { label: "Process", href: "/#process" },
  { label: "Creators", href: "/creators" },
  { label: "Campaigns", href: "/campaigns" },
  { label: "For Brands", href: "/brands" },
  { label: "Pricing", href: "/pricing" },
  { label: "Contact", href: "/contact" },
];

export const servicesNav: NavItem[] = [
  { label: "Branding", href: "/services/branding-and-identity" },
  { label: "Influencer Marketing", href: "/services/influencer-marketing" },
  { label: "Performance Marketing", href: "/services/digital-marketing-advertising" },
  { label: "Social Media", href: "/services/social-media-marketing" },
  { label: "Creative Design", href: "/services/creative-design" },
  { label: "Video Production", href: "/services/video-production" },
  { label: "Lead Generation", href: "/services/lead-generation" },
  { label: "SEO", href: "/services/seo" },
  { label: "CRM & Automation", href: "/services/business-systems-automation" },
  { label: "WhatsApp Marketing", href: "/services/whatsapp-marketing" },
  { label: "Website Development", href: "/services/website-design-development" },
  { label: "Analytics & Reporting", href: "/services/analytics-reporting" },
];

export const companyNav: NavItem[] = [
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
  { label: "Brand System", href: "/brand-system" },
];

export const accountNav: NavItem[] = [
  { label: "Login", href: "/login" },
  { label: "Join HRIX", href: "/register" },
];
