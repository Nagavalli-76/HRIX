import { HrixLogo } from "@/components/brand/HrixLogo";
import { Button } from "@/components/ui/Button";

export function Hero() {
  return (
    <section
      aria-labelledby="hero-heading"
      className="relative isolate overflow-hidden"
    >
      {/* Ambient light, kept off the logo: it comes from the background only. */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -right-40 top-1/3 h-[720px] w-[720px] rounded-full bg-[radial-gradient(closest-side,rgba(139,92,246,0.14),transparent)]" />
        <div className="absolute -left-48 bottom-0 h-[560px] w-[560px] rounded-full bg-[radial-gradient(closest-side,rgba(79,124,255,0.09),transparent)]" />
        <div className="absolute inset-0 opacity-40 [background-image:radial-gradient(rgba(255,255,255,0.14)_1px,transparent_1px)] [background-size:28px_28px] [mask-image:radial-gradient(ellipse_at_72%_50%,black,transparent_62%)]" />
      </div>

      <div className="container-page pt-12 md:pt-16">
        <HrixLogo variant="hero" priority />

        <p className="mt-5 text-sm font-medium uppercase tracking-[0.16em] text-orange-300">
          Digital Growth &amp; Technology Solutions
        </p>
        <h1 id="hero-heading" className="text-display mt-4 md:mt-6">
          Build Your Brand. Reach Your Audience. Grow Your Business.
        </h1>

        <div className="mt-8 max-w-3xl pb-16 lg:mt-10 lg:pb-20">
          <div>
            <p className="max-w-[32rem] text-lg text-muted md:text-xl">
              HRIX is a digital growth and technology solutions company helping
              businesses establish their digital presence, connect with potential
              customers and generate business opportunities.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button href="/contact" size="lg">
                Let&apos;s Grow Your Business
              </Button>
              <Button href="/register?role=creator" variant="secondary" size="lg">
                Join as Creator
              </Button>
            </div>

            <p className="mt-5 text-sm text-faint">
              Creator membership from ₹99/month
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
