import type { Metadata, Viewport } from "next";
import { Bricolage_Grotesque, Instrument_Sans } from "next/font/google";
import "./globals.css";
import { AmbientBackground } from "@/components/marketing/AmbientBackground";
import { HrixCursor } from "@/components/ui/HrixCursor";
import { SITE_URL } from "@/lib/seo/site";

const SITE_DESCRIPTION =
  "HRIX helps businesses build their brand, reach their audience and grow through digital marketing, websites, lead generation, creator collaborations and business automation.";

// Display: Bricolage Grotesque, with its width axis so headlines can run
// condensed and heavy. Body: Instrument Sans, quiet and highly legible.
const display = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-display",
  axes: ["wdth"],
  display: "swap",
});

const body = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "HRIX | Digital Growth & Technology Solutions",
    template: "%s | HRIX",
  },
  description: SITE_DESCRIPTION,
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "HRIX | Digital Growth & Technology Solutions",
    description: SITE_DESCRIPTION,
    url: SITE_URL,
    siteName: "HRIX",
    locale: "en_IN",
    type: "website",
    images: [
      {
        url: `${SITE_URL}/brand/hrix-logo.png`,
        width: 1200,
        height: 630,
        alt: "HRIX — Digital Growth & Technology Solutions",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "HRIX | Digital Growth & Technology Solutions",
    description: SITE_DESCRIPTION,
    images: [`${SITE_URL}/brand/hrix-logo.png`],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export const viewport: Viewport = {
  themeColor: "#050505",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <AmbientBackground />
        <HrixCursor />
        <a
          href="#main"
          className="fixed left-4 top-4 z-[200] -translate-y-24 rounded-md bg-ink px-4 py-2 text-sm font-medium text-canvas transition-transform focus:translate-y-0"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
