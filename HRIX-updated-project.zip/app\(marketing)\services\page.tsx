import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, CheckCircle2, Sparkles, Layers, Megaphone, Users, Target, Cpu, Globe, Palette, Video, Search, MessageCircle, BarChart3 } from "lucide-react";
import { serviceList } from "@/data/services";
import { GlassCard } from "@/components/ui/GlassCard";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { JsonLd } from "@/components/seo/JsonLd";
import { getBreadcrumbSchema, getOrganizationSchema } from "@/lib/seo/schema";
import { SITE_URL } from "@/lib/seo/site";

export const metadata: Metadata = {
  title: {
    absolute: "Services | HRIX Digital Growth & Technology Solutions",
  },
  description:
    "Explore HRIX services across branding, creative design, video, digital marketing, websites, search, lead generation and business automation.",
  alternates: {
    canonical: "/services",
  },
  openGraph: {
    title: "Services | HRIX Digital Growth & Technology Solutions",
    description:
      "Explore HRIX services across branding, creative design, video, digital marketing, websites, search, lead generation and business automation.",
    url: `${SITE_URL}/services`,
    siteName: "HRIX",
    images: [`${SITE_URL}/brand/hrix-logo.png`],
  },
};

const SERVICE_ICONS: Record<string, typeof Sparkles> = {
  "branding-and-identity": Layers,
  "influencer-marketing": Users,
  "digital-marketing-advertising": Megaphone,
  "social-media-marketing": Sparkles,
  "lead-generation": Target,
  "business-systems-automation": Cpu,
  "website-design-development": Globe,
  "creative-design": Palette,
  "video-production": Video,
  seo: Search,
  "whatsapp-marketing": MessageCircle,
  "analytics-reporting": BarChart3,
};

const SERVICE_TABLE_ROWS = [
  ["Branding", "Brand identity and positioning", "Project branding"],
  ["Social Media", "Account management and content strategy", "Project promotion"],
  ["Creative Design", "Posters, banners and graphics", "Plot and property advertisements"],
  ["Video Production", "Reels and cinematic editing", "Property walkthroughs"],
  ["Performance Marketing", "Meta and Google Ads", "Buyer acquisition campaigns"],
  ["Lead Generation", "Enquiry capture systems", "Potential buyer enquiries"],
  ["Website Development", "Websites and landing pages", "Property project websites"],
  ["SEO", "Search optimization", "Local property visibility"],
  ["CRM & Automation", "Lead management workflows", "Buyer follow-up systems"],
  ["WhatsApp Marketing", "Customer communication", "Enquiry handling"],
  ["Influencer Marketing", "Creator collaborations", "Local project promotion"],
  ["Analytics & Reporting", "Campaign performance analysis", "Lead and campaign tracking"],
] as const;

export default function ServicesIndexPage() {
  const breadcrumbSchema = getBreadcrumbSchema([
    { name: "Home", path: "/" },
    { name: "Services", path: "/services" },
  ]);
  const orgSchema = getOrganizationSchema();

  return (
    <>
      <JsonLd data={[orgSchema, breadcrumbSchema]} />

      <div className="container-page py-16 md:py-24">
        {/* Header Section */}
        <div className="mx-auto max-w-3xl text-center">
          <Badge tone="violet" className="mb-4">
            Digital Growth & Technology Solutions
          </Badge>
          <h1 className="text-display">Digital services for business growth</h1>
          <p className="mt-5 text-lg text-muted">
            Our services apply across industries, with examples of how they work for real estate.
          </p>
        </div>

        <section aria-labelledby="service-mapping-heading" className="mt-14">
          <h2 id="service-mapping-heading" className="sr-only">Service applications</h2>
          <div className="overflow-x-auto rounded-xl border border-line">
            <table className="w-full min-w-[680px] border-collapse text-left text-sm">
              <thead className="bg-surface-raised text-ink">
                <tr>
                  {["Service", "What HRIX delivers", "Real estate application"].map((heading) => (
                    <th key={heading} scope="col" className="px-5 py-4 font-semibold">{heading}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {SERVICE_TABLE_ROWS.map(([service, delivery, application]) => (
                  <tr key={service} className="border-t border-line/70 text-muted">
                    <th scope="row" className="px-5 py-4 font-medium text-ink">{service}</th>
                    <td className="px-5 py-4">{delivery}</td>
                    <td className="px-5 py-4">{application}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Services Grid */}
        <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {serviceList.map((service, index) => {
            const Icon = SERVICE_ICONS[service.slug] || Sparkles;
            const isFeatured = index === 0;

            return (
              <GlassCard
                key={service.slug}
                tone={isFeatured ? "accent" : "default"}
                interactive
                className="flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-violet/10 text-violet">
                      <Icon className="h-5 w-5" aria-hidden />
                    </div>
                    <Badge tone="neutral">Service {index + 1}</Badge>
                  </div>

                  <h2 className="mt-5 text-xl font-semibold text-ink">
                    <Link
                      href={`/services/${service.slug}`}
                      className="transition-colors hover:text-violet-soft"
                    >
                      {service.name}
                    </Link>
                  </h2>

                  <p className="mt-3 text-sm text-muted line-clamp-3">
                    {service.summary}
                  </p>

                  <div className="mt-6 border-t border-line/50 pt-4">
                    <span className="text-xs font-semibold uppercase tracking-wider text-faint">
                      Key Deliverables
                    </span>
                    <ul className="mt-2.5 space-y-1.5 text-xs text-muted">
                      {service.deliverables.slice(0, 3).map((item) => (
                        <li key={item.title} className="flex items-start gap-2">
                          <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 text-violet shrink-0" aria-hidden />
                          <span>{item.title}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-8 pt-4">
                  <Link
                    href={`/services/${service.slug}`}
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-violet-soft hover:underline"
                  >
                    View details & workflow
                    <ArrowRight className="h-4 w-4" aria-hidden />
                  </Link>
                </div>
              </GlassCard>
            );
          })}
        </div>

        <p className="mx-auto mt-14 max-w-3xl text-center text-lg font-medium text-ink">
          Connect every stage of digital marketing with measurable business opportunities.
        </p>

        {/* Bottom CTA Banner */}
        <div className="mt-20 rounded-2xl border border-line bg-gradient-to-br from-surface to-surface-raised p-8 text-center md:p-12">
          <h2 className="text-headline">Have a specific project in mind?</h2>
          <p className="mx-auto mt-4 max-w-xl text-muted">
            Tell us about your business goals and the audience you want to reach.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button href="/contact" size="lg">
              Contact HRIX Team
            </Button>
            <Button href="/register" variant="secondary" size="lg">
              Join the Network
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
