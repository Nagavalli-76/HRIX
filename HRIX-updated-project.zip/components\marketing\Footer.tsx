import Link from "next/link";
import { Facebook, Instagram, Linkedin } from "lucide-react";
import { HrixLogo } from "@/components/brand/HrixLogo";
import { accountNav, companyNav, primaryNav, servicesNav, type NavItem } from "@/lib/navigation";

function FooterColumn({ title, items }: { title: string; items: NavItem[] }) {
  return (
    <div>
      <h2 className="font-display text-sm font-semibold text-ink">{title}</h2>
      <ul className="mt-4 space-y-2.5">
        {items.map((item) => (
          <li key={item.href}>
            <Link
              href={item.href}
              className="text-sm text-muted transition-colors hover:text-ink"
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-line/70 bg-canvas-alt">
      <div className="container-page grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1.3fr_0.9fr_0.9fr] lg:gap-8">
        <div className="max-w-xs">
          <HrixLogo variant="footer" href="/" />
          <p className="mt-5 text-sm text-muted leading-relaxed">
            HRIX is a digital growth and technology solutions company.
          </p>
          <div className="mt-4 text-xs text-faint">
            Official contact:{" "}
            <a
              href="mailto:hrixofficial@gmail.com"
              className="text-muted hover:text-ink transition-colors"
            >
              hrixofficial@gmail.com
            </a>
          </div>
          <a href="https://hrixofficial.in" className="mt-2 inline-block text-xs text-muted hover:text-ink">
            hrixofficial.in
          </a>
          <nav aria-label="Social media" className="mt-5 flex items-center gap-3">
            <a href="https://www.instagram.com/HRIX_INSTAGRAM_HANDLE_TODO/" target="_blank" rel="noreferrer" aria-label="Instagram (handle to be supplied)" className="text-muted transition-colors hover:text-ink">
              <Instagram className="h-5 w-5" aria-hidden />
            </a>
            <a href="https://www.facebook.com/HRIX_FACEBOOK_HANDLE_TODO/" target="_blank" rel="noreferrer" aria-label="Facebook (handle to be supplied)" className="text-muted transition-colors hover:text-ink">
              <Facebook className="h-5 w-5" aria-hidden />
            </a>
            <a href="https://www.linkedin.com/company/HRIX_LINKEDIN_HANDLE_TODO/" target="_blank" rel="noreferrer" aria-label="LinkedIn (handle to be supplied)" className="text-muted transition-colors hover:text-ink">
              <Linkedin className="h-5 w-5" aria-hidden />
            </a>
          </nav>
        </div>
        <FooterColumn title="Platform" items={primaryNav} />
        <FooterColumn title="Services" items={servicesNav} />
        <FooterColumn title="Company" items={companyNav} />
        <FooterColumn title="Account" items={accountNav} />
      </div>
      <div className="border-t border-line/70">
        <div className="container-page flex flex-col gap-3 py-6 text-sm text-faint sm:flex-row sm:items-center sm:justify-between sm:gap-4">
          <span>© {new Date().getFullYear()} HRIX. All rights reserved.</span>
          <span className="sm:text-right">Creator membership from ₹99/month.</span>
        </div>
      </div>
    </footer>
  );
}
