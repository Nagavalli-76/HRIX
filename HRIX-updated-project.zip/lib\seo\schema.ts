import { SITE_URL } from "@/lib/seo/site";

export function getOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "HRIX",
    url: SITE_URL,
    logo: `${SITE_URL}/brand/hrix-logo.png`,
    sameAs: [
      "https://www.instagram.com/HRIX_INSTAGRAM_HANDLE_TODO/",
      "https://www.facebook.com/HRIX_FACEBOOK_HANDLE_TODO/",
      "https://www.linkedin.com/company/HRIX_LINKEDIN_HANDLE_TODO/",
    ],
    email: "hrixofficial@gmail.com",
    description:
      "HRIX is a digital growth and technology solutions company.",
  };
}

export function getWebSiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "HRIX",
    url: SITE_URL,
    description:
      "HRIX helps businesses build their brand, reach their audience and grow through digital marketing, websites, lead generation, creator collaborations and business automation.",
  };
}

export interface BreadcrumbItem {
  name: string;
  path: string;
}

export function getBreadcrumbSchema(items: BreadcrumbItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.path.startsWith("http") ? item.path : `${SITE_URL}${item.path}`,
    })),
  };
}

export interface ServiceSchemaProps {
  name: string;
  serviceType: string;
  description: string;
  path: string;
}

export function getServiceSchema({ name, serviceType, description, path }: ServiceSchemaProps) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name,
    serviceType,
    description,
    url: `${SITE_URL}${path}`,
    provider: {
      "@type": "Organization",
      name: "HRIX",
      url: SITE_URL,
    },
  };
}

export interface FAQItem {
  question: string;
  answer: string;
}

export function getFAQSchema(faqs: FAQItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };
}
